# nodeAssignment
basic apis
